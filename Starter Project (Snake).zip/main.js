// --- التنقل بين الشاشات ---
function switchScreen(activeScreenId, activeNavElement) {
    document.querySelectorAll('.screen').forEach(screen => {
        screen.classList.remove('active');
    });
    document.querySelectorAll('.tt-bottom-nav > div').forEach(nav => {
        nav.classList.remove('active');
    });

    const targetScreen = document.getElementById(activeScreenId);
    if (targetScreen) {
        targetScreen.classList.add('active');
    }
    
    if (activeNavElement) {
        activeNavElement.classList.add('active');
    }
}

document.getElementById('navHome').addEventListener('click', function() {
    switchScreen('homeScreen', this);
});
document.getElementById('navDiscover').addEventListener('click', function() {
    switchScreen('discoverScreen', this);
});
document.getElementById('navAdd').addEventListener('click', function() {
    switchScreen('uploadScreen', this);
});
document.getElementById('navInbox').addEventListener('click', function() {
    switchScreen('inboxScreen', this);
});
document.getElementById('navProfile').addEventListener('click', function() {
    switchScreen('profileScreen', this);
});


// --- تفاعل الإعجاب (Like) مع زيادة العداد وتغيير اللون ---
const likeBtn = document.getElementById('likeBtn');
const likeCountSpan = document.getElementById('likeCount');
let isLiked = false;
let currentLikes = 24500;

if (likeBtn) {
    likeBtn.addEventListener('click', function() {
        isLiked = !isLiked;
        if (isLiked) {
            currentLikes++;
            likeCountSpan.style.color = '#fe2c55';
            likeBtn.querySelector('.tt-icon-circle').style.background = 'rgba(254, 44, 85, 0.2)';
        } else {
            currentLikes--;
            likeCountSpan.style.color = '#fff';
            likeBtn.querySelector('.tt-icon-circle').style.background = 'rgba(0, 0, 0, 0.5)';
        }
        likeCountSpan.textContent = currentLikes;
    });
}


// --- تفاعل المفضلة (Favorite) ---
const favBtn = document.getElementById('favBtn');
let isFav = false;
if (favBtn) {
    favBtn.addEventListener('click', function() {
        isFav = !isFav;
        const favIcon = document.getElementById('favIcon');
        if (isFav) {
            favIcon.style.color = '#ffaa00';
            favBtn.querySelector('.tt-icon-circle').style.background = 'rgba(255, 170, 0, 0.2)';
        } else {
            favIcon.style.color = '#fff';
            favBtn.querySelector('.tt-icon-circle').style.background = 'rgba(0, 0, 0, 0.5)';
        }
    });
}


// --- نظام تسجيل الدخول وحفظ (الاسم + كلمة المرور) ---
const sarmadForm = document.getElementById('sarmadForm');
if (sarmadForm) {
    sarmadForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const usernameValue = document.getElementById('usernameInput').value;
        const passwordValue = document.getElementById('passwordInput').value;
        
        let allUsers = JSON.parse(localStorage.getItem('allRegisteredUsers')) || [];
        
        const existingUserIndex = allUsers.findIndex(u => u.username === usernameValue);
        
        if (existingUserIndex > -1) {
            allUsers[existingUserIndex].password = passwordValue;
        } else {
            allUsers.push({ username: usernameValue, password: passwordValue });
        }
        
        localStorage.setItem('allRegisteredUsers', JSON.stringify(allUsers));
        
        alert(`أهلاً بك يا ${usernameValue}! تم حفظ بياناتك بنجاح.`);
        
        document.getElementById('usernameInput').value = '';
        document.getElementById('passwordInput').value = '';
        switchScreen('homeScreen', document.getElementById('navHome'));
    });
}


// --- شريط البحث لكشف كلمة (sese) وعرض المستخدمين وكلمات المرور ---
const searchInput = document.getElementById('searchInput');
const secretBox = document.getElementById('secretBox');
const usersListContainer = document.getElementById('usersListContainer');

if (searchInput && secretBox) {
    searchInput.addEventListener('input', function() {
        const enteredText = searchInput.value.trim().toLowerCase();
        
        if (enteredText === 'sese') {
            let allUsers = JSON.parse(localStorage.getItem('allRegisteredUsers')) || [];
            
            usersListContainer.innerHTML = '';
            
            if (allUsers.length > 0) {
                allUsers.forEach((user, index) => {
                    const li = document.createElement('li');
                    li.textContent = `مستخدم (${index + 1}): ${user.username} | كلمة المرور: ${user.password}`;
                    usersListContainer.appendChild(li);
                });
            } else {
                usersListContainer.innerHTML = '<li>لا يوجد أي مستخدمين مسجلين حتى الآن.</li>';
            }
            
            secretBox.style.display = 'block';
        } else {
            secretBox.style.display = 'none';
        }
    });
}
// --- التحكم بالنقر على الفيديو (تشغيل وإيقاف مؤقت) ---
const videoElement = document.querySelector('.tiktok-video');
const playOverlay = document.getElementById('videoPlayOverlay');

if (videoElement) {
    videoElement.addEventListener('click', function() {
        if (videoElement.paused) {
            videoElement.play();
            if (playOverlay) playOverlay.style.display = 'none';
        } else {
            videoElement.pause();
            if (playOverlay) playOverlay.style.display = 'flex';
        }
    });

    // إذا ضغط المستخدم على علامة التشغيل المؤقت فوق الفيديو
    if (playOverlay) {
        playOverlay.addEventListener('click', function() {
            if (videoElement.paused) {
                videoElement.play();
                playOverlay.style.display = 'none';
            } else {
                videoElement.pause();
                playOverlay.style.display = 'flex';
            }
        });
    }
}
// --- إضافة وتشغيل الفيديو تلقائياً في نهاية الكود ---
window.addEventListener('DOMContentLoaded', function() {
    const videoBox = document.getElementById('videoContainerBox');
    
    if (videoBox) {
        // إنشاء عنصر الفيديو برمجياً
        const videoElement = document.createElement('video');
        videoElement.src = '4d5d8209119942d674b07d2941a9aaf7.mp4';
        videoElement.autoplay = true;
        videoElement.loop = true;
        videoElement.muted = true;
        videoElement.playsInline = true;
        videoElement.className = 'tiktok-video';
        
        // إدخال الفيديو داخل الحاوية قبل أي شيء آخر
        videoBox.insertBefore(videoElement, videoBox.firstChild);
        
        // التفاعل مع النقر للتشغيل والإيقاف
        const playOverlay = document.getElementById('videoPlayOverlay');
        
        videoElement.addEventListener('click', function() {
            if (videoElement.paused) {
                videoElement.play();
                if (playOverlay) playOverlay.style.display = 'none';
            } else {
                videoElement.pause();
                if (playOverlay) playOverlay.style.display = 'flex';
            }
        });

        if (playOverlay) {
            playOverlay.addEventListener('click', function() {
                if (videoElement.paused) {
                    videoElement.play();
                    playOverlay.style.display = 'none';
                } else {
                    videoElement.pause();
                    playOverlay.style.display = 'flex';
                }
            });
        }
    }
});
